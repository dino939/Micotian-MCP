package com.denger.micotian.module.modules.render;

import com.denger.micotian.module.Category;
import com.denger.micotian.module.Module;

public class Testy extends Module {

    public Testy(){super("Testy", Category.Render,0);}


}
