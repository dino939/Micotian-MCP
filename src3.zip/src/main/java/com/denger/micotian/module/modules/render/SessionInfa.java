package com.denger.micotian.module.modules.render;

import com.denger.micotian.Micotian;
import com.denger.micotian.module.Category;
import com.denger.micotian.module.Module;
import com.denger.micotian.utils.CFont.FontUtils;
import com.denger.micotian.utils.RenderUtils;
import com.denger.micotian.utils.font.FontUtil;
import com.mojang.realmsclient.client.Request;
import net.minecraft.client.gui.ScaledResolution;

import java.awt.*;
import java.text.SimpleDateFormat;

public class SessionInfa extends Module {
    public SessionInfa() {
        super("SessionInfa", Category.Render, 0);
    }

    @Override
    public void onRender2D() {
        super.onRender2D();
        final int[] counter = {1};
        String server;
        if (mc.isSingleplayer()) {
            server = "localhost";
        } else {
            server = mc.getCurrentServerData().serverIP.toLowerCase();
        }
        final double prevZ = mc.player.posZ - mc.player.prevPosZ;
        final double prevX = mc.player.posX - mc.player.prevPosX;
        final double lastDist = Math.sqrt(prevX * prevX + prevZ * prevZ);
        final double currSpeed = lastDist * 15.3571428571;
        final String speed = String.format("%.2f bps", currSpeed);
        double posX = 567.0;
        double posY = -435.0;
        ScaledResolution sr = new ScaledResolution(mc);
        final float scaledWidth = sr.getScaledWidth();
        float x = (float) ((double) (scaledWidth / 2.0F) - posX);
        float y = (float) ((double) (scaledWidth / 2.0F) + posY);
        RenderUtils.drawCastomLitium((int) (x + 90.0F), (int) ((double) y - 1.5), (int) (x + 200.5F), (int) (y + 60.0F), 6);
        double posX2 = 567.0;
        double posY2 = -550.0;
        final float scaledWidth2 = sr.getScaledWidth();
        float x2 = (float) ((double) (scaledWidth / 2.0F) - posX2);
        float y2 = (float) ((double) (scaledWidth / 2.0F) + posY2);
        RenderUtils.drawCastomLitium((int) (x2 + 90.0F),  (int) ((double) y2 - 10), (int) (x2 + 200.5F), (int) (y2 + 0.1F),  4);
        FontUtils.fr.drawString("       Session Info         ", 5, 49, new Color(255, 255, 255).getRGB());
        FontUtils.fr.drawString("Server: " + server, 6, 65, new Color(255, 255, 255).getRGB());
        FontUtils.fr.drawString("Name: " + mc.player.getName(), 6, 75, new Color(255, 255, 255).getRGB());
        FontUtils.fr.drawString("Speed: " + speed, 6, 85, new Color(255, 255, 255).getRGB());
    }
}

