package com.denger.micotian.module.modules.render;

import com.denger.micotian.module.Category;
import com.denger.micotian.module.Module;

public class ShaderESP extends Module {
    public ShaderESP() {
        super("ShaderESP", Category.Render, 0);
    }
}
