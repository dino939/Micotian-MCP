package com.denger.micotian.module.modules.render;

import com.denger.micotian.module.Category;
import com.denger.micotian.module.Module;
import com.denger.micotian.module.setting.settings.BooleanSetting;

public class NameProtect extends Module {
    private BooleanSetting friends;


    public NameProtect() {
        super("NameProtect", Category.Render, 0);

    }

}
