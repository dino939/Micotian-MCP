package com.denger.micotian.ClickGui;

import com.denger.micotian.module.Category;
import com.denger.micotian.utils.CFont.FontUtils;
import com.denger.micotian.utils.Referents;
import com.denger.micotian.utils.RenderUtil;
import com.denger.micotian.utils.RenderUtils;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiScreen;
import org.lwjgl.input.Mouse;

import java.awt.*;
import java.io.IOException;

public class ClickGui extends GuiScreen {
    public static Category currentcat;
    public Category selectedCategory;
    public static boolean click;
    public static int but;
    public static int x;
    public static int y;
    public static int x1;
    public static int y1;
    public static int Xpos = 25;
    public static int Ypos = 25;
    public ClickGui(){}

    @Override
    public void initGui(){
        super.initGui();
        x = Xpos;
        y = Ypos;
        x1 = Xpos + 310;
        y1 = Ypos + 250;

    }
    int offset = 0;
    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        offset = 0;
        super.drawScreen(mouseX, mouseY, partialTicks);
        for (Category category : Category.values()) {
            if (ishover(x+10,y +48+ offset,x+1+((x1-x)/3),y + 72 + offset,mouseX, mouseY) && Mouse.isButtonDown(0)) {
                selectedCategory = category;
            }
            offset += 33;
        }
        if(ishover(x+1, y - 8, x+1+((x1-x)/3), y + 15, mouseX, mouseY)){
            if(Mouse.isButtonDown(0)){
                Xpos = mouseX - (((x1 - x) / 2 - (x1 - x) / 3));
                Ypos = mouseY - 4;
                x = Xpos;
                y = Ypos;
                x1 = Xpos + 310;
                y1 = Ypos + 250;

            }
        }
        RenderUtils.drawCastomLitium(x, y - 10, x1, y1, 1,-1);
        RenderUtils.drawCastomLitium(x+1, y - 8, x+1+((x1-x)/3), y + 15, 1,-1);
        FontUtils.fr.drawString(Referents.NAME+ " Client ",x+10, y - 6,-1);
        FontUtils.fr.drawString(Referents.VERSION,x+35, y + 4,-1);
        int offset = 0;
        for (Category category : Category.values()) {
            RenderUtils.drawCastomLitium(x+10,y +48+ offset,x+1+((x1-x)/3),y + 72 + offset,category.equals(selectedCategory) ? 2 : 1,category.equals(selectedCategory) ? -2 : 0);
            FontUtils.fr.drawString(category.name(),x+15,y +56+ offset,category.equals(selectedCategory) ? -1 : new Color(170,170,170).getRGB());
            offset += 33;
        }

    }


    public static boolean ishover(int xx, int yy, int xxx, int yyy, int mouseX, int mouseY){
        if(mouseX > xx && mouseX < xxx && mouseY > yy && mouseY < yyy){
            return true;
        }
        return false;
    }
    @Override
    protected void mouseClicked(int mouseX, int mouseY, int mouseButton) throws IOException {
        super.mouseClicked(mouseX, mouseY, mouseButton);
        click = true;
        but = mouseButton;
    }

}
