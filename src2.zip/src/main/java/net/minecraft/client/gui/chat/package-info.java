@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package net.minecraft.client.gui.chat;

import mcp.MethodsReturnNonnullByDefault;
import javax.annotation.ParametersAreNonnullByDefault;