package com.denger.micotian.module;

public enum Category {
    Combat, Move, Render, Misc
}
