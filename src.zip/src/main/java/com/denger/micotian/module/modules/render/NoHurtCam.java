package com.denger.micotian.module.modules.render;

import com.denger.micotian.module.Category;
import com.denger.micotian.module.Module;

public class NoHurtCam extends Module {
    public NoHurtCam() {
        super("NoHurtCam", Category.Render, 0);
    }

    @Override
    public void onUpdate() {
        super.onUpdate();

    }
}
