package com.denger.micotian.utils;

import java.awt.*;

public final class RoundedUtil {

      public static Color drawRound(float x, float y, float width, float height, float radius, Color color) {
          drawRound(x, y, width, height, radius,  color);
          return color;
      }
}
