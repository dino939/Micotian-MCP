package com.denger.micotian.utils;

public class TextUtill {
    public TextUtill(String test){
        mc = System.currentTimeMillis();
        this.text = test;
    }
    String text;
    long mc;
    public String anim(){

        return text;
    }
}
