package com.denger.micotian.utils;

public class Referents {
    public static String NAME = "Micotian";
    public static String VERSION = "V0.0.1";

}
