/**
 * Provides 3D vector mathematics classes.
 */
package javax.vecmath;
